﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Footballers;User Id=sa;Password=yourStrong(!)Password;";
    }
}
