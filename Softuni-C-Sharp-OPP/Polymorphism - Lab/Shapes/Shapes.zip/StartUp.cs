﻿using System;

namespace Shapes
{
    public class StartUp
    {
        static void Main()
        {
            Shape shape = null;

            string typeShape = Console.ReadLine();

            if (typeShape == "Rectangle")
            {
                double height = double.Parse(Console.ReadLine());
                double width = double.Parse(Console.ReadLine());
                shape = new Rectangle(height, width);
            }
            else if (typeShape == "Circle")
            {
                double radius = double.Parse(Console.ReadLine());
                shape = new Circle(radius);
            }

            Console.WriteLine((int)shape.CalculatePerimeter());
            Console.WriteLine((int)shape.CalculateArea());
            Console.WriteLine(shape.Draw());
        }
    }
}
