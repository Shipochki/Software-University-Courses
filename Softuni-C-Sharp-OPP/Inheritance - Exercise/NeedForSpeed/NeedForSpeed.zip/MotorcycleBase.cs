﻿namespace NeedForSpeed
{
    public class MotorcycleBase
    {
    }
}