﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Motorcycle motor = new Motorcycle(200, 7);
            motor.Drive(1);
            System.Console.WriteLine(motor.Fuel);
        }
    }
}
